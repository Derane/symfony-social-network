<?php

return [
    'Names' => [
        'PHP' => [
            '₱',
            'Philippine Peso',
        ],
    ],
];
