<?php

return [
    'Names' => [
        'VEF' => [
            'Bs.',
            'bolívar venezolano (2008–2018)',
        ],
        'VES' => [
            'Bs.S',
            'bolívar soberano',
        ],
    ],
];
