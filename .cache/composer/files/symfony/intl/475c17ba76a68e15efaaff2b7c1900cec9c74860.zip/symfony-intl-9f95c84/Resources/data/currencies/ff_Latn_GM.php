<?php

return [
    'Names' => [
        'GMD' => [
            'D',
            'Dalasi Gammbi',
        ],
    ],
];
