<?php

return [
    'Names' => [
        'SLE' => [
            'Le',
            'SLE',
        ],
    ],
];
