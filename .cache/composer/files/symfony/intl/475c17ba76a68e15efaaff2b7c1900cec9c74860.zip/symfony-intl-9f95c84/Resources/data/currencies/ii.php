<?php

return [
    'Names' => [
        'CNY' => [
            '¥',
            'CNY',
        ],
    ],
];
