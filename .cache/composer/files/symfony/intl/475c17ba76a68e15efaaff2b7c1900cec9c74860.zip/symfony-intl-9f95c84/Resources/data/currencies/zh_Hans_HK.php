<?php

return [
    'Names' => [
        'CNY' => [
            'CN¥',
            '人民币',
        ],
        'KYD' => [
            'KYD',
            '开曼群岛元',
        ],
    ],
];
