<?php

return [
    'Names' => [
        'af' => 'Afreeki',
        'bn' => 'Bangla',
        'bo' => 'Tibbati',
        'ckb' => 'Kurdish, Sorani',
        'crh' => 'Crimean Turkish',
        'fa' => 'Faarsi',
        'ff' => 'Fulah',
        'lah' => 'Lahnda',
        'mus' => 'Muscogee',
        'nan' => 'Min Nan',
        'nb' => 'Norwegian Bokmal',
        'ug' => 'Uighur',
        'wal' => 'walamo',
    ],
    'LocalizedNames' => [
        'nds_NL' => 'Low Saxon',
    ],
];
