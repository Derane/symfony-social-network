<?php

return [
    'Names' => [
        'GYD' => [
            '$',
            'Guyanaese Dollar',
        ],
    ],
];
