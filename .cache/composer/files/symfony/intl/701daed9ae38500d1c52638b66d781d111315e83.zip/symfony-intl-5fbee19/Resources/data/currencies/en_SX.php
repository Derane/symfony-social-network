<?php

return [
    'Names' => [
        'ANG' => [
            'NAf.',
            'Netherlands Antillean Guilder',
        ],
    ],
];
