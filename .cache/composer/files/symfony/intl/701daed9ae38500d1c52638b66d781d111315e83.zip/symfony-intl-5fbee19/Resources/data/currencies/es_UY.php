<?php

return [
    'Names' => [
        'USD' => [
            'US$',
            'dólar estadounidense',
        ],
        'UYU' => [
            '$',
            'peso uruguayo',
        ],
        'UYW' => [
            'UP',
            'unidad previsional uruguayo',
        ],
    ],
];
