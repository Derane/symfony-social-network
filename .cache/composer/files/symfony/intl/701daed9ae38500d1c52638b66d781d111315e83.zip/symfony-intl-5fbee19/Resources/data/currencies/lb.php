<?php

return [
    'Names' => [
        'ADP' => [
            'ADP',
            'Andorranesch Peseta',
        ],
        'AED' => [
            'AED',
            'VAE-Dirham',
        ],
        'AFA' => [
            'AFA',
            'Afghanesch Afghani (1927–2002)',
        ],
        'AFN' => [
            'AFN',
            'Afghanesch Afghani',
        ],
        'ALL' => [
            'ALL',
            'Albanesche Lek',
        ],
        'AMD' => [
            'AMD',
            'Armeneschen Dram',
        ],
        'ANG' => [
            'ANG',
            'Antillen-Gulden',
        ],
        'AOA' => [
            'AOA',
            'Angolanesche Kwanza',
        ],
        'AOK' => [
            'AOK',
            'Angolanesche Kwanza (1977–1990)',
        ],
        'AON' => [
            'AON',
            'Angolaneschen Neie Kwanza (1990–2000)',
        ],
        'AOR' => [
            'AOR',
            'Angolanesche Kwanza Reajustado (1995–1999)',
        ],
        'ARA' => [
            'ARA',
            'Argentineschen Austral',
        ],
        'ARP' => [
            'ARP',
            'Argentinesche Peso (1983–1985)',
        ],
        'ARS' => [
            'ARS',
            'Argentinesche Peso',
        ],
        'ATS' => [
            'öS',
            'Éisträichesche Schilling',
        ],
        'AUD' => [
            'AU$',
            'Australeschen Dollar',
        ],
        'AWG' => [
            'AWG',
            'Aruba-Florin',
        ],
        'AZM' => [
            'AZM',
            'Aserbaidschan-Manat (1993–2006)',
        ],
        'AZN' => [
            'AZN',
            'Aserbaidschan-Manat',
        ],
        'BAD' => [
            'BAD',
            'Bosnien an Herzegowina Dinar (1992–1994)',
        ],
        'BAM' => [
            'BAM',
            'Bosnien an Herzegowina Konvertéierbar Mark',
        ],
        'BBD' => [
            'BBD',
            'Barbados-Dollar',
        ],
        'BDT' => [
            'BDT',
            'Bangladesch-Taka',
        ],
        'BEC' => [
            'BEC',
            'Belsche Frang (konvertibel)',
        ],
        'BEF' => [
            'BEF',
            'Belsche Frang',
        ],
        'BEL' => [
            'BEL',
            'Belsche Finanz-Frang',
        ],
        'BGL' => [
            'BGL',
            'Bulgaresch Lew (1962–1999)',
        ],
        'BGN' => [
            'BGN',
            'Bulgaresch Lew',
        ],
        'BHD' => [
            'BHD',
            'Bahrain-Dinar',
        ],
        'BIF' => [
            'BIF',
            'Burundi-Frang',
        ],
        'BMD' => [
            'BMD',
            'Bermuda-Dollar',
        ],
        'BND' => [
            'BND',
            'Brunei-Dollar',
        ],
        'BOB' => [
            'BOB',
            'Bolivianesche Boliviano',
        ],
        'BOP' => [
            'BOP',
            'Bolivianesche Peso',
        ],
        'BOV' => [
            'BOV',
            'Bolivianseche Mvdol',
        ],
        'BRB' => [
            'BRB',
            'Brasilianesche Cruzeiro Novo (1967–1986)',
        ],
        'BRC' => [
            'BRC',
            'Brasilianesche Cruzado (1986–1989)',
        ],
        'BRE' => [
            'BRE',
            'Brasilianesche Cruzeiro (1990–1993)',
        ],
        'BRL' => [
            'R$',
            'Brasilianesche Real',
        ],
        'BRN' => [
            'BRN',
            'Brasilianesche Cruzado Novo (1989–1990)',
        ],
        'BRR' => [
            'BRR',
            'Brasilianesche Cruzeiro (1993–1994)',
        ],
        'BRZ' => [
            'BRZ',
            'Brasilianesche Cruzeiro (1942–1967)',
        ],
        'BSD' => [
            'BSD',
            'Bahama-Dollar',
        ],
        'BTN' => [
            'BTN',
            'Bhutan-Ngultrum',
        ],
        'BUK' => [
            'BUK',
            'Birmanesche Kyat',
        ],
        'BWP' => [
            'BWP',
            'Botswanesch Pula',
        ],
        'BYB' => [
            'BYB',
            'Wäissrussesche Rubel (1994–1999)',
        ],
        'BYN' => [
            'BYN',
            'Wäissrussesche Rubel',
        ],
        'BYR' => [
            'BYR',
            'Wäissrussesche Rubel (2000–2016)',
        ],
        'BZD' => [
            'BZD',
            'Belize-Dollar',
        ],
        'CAD' => [
            'CA$',
            'Kanadeschen Dollar',
        ],
        'CDF' => [
            'CDF',
            'Kongo-Frang',
        ],
        'CHE' => [
            'CHE',
            'WIR-Euro',
        ],
        'CHF' => [
            'CHF',
            'Schwäizer Frang',
        ],
        'CHW' => [
            'CHW',
            'WIR-Frang',
        ],
        'CLF' => [
            'CLF',
            'Chileneschen Unidad de Fomento',
        ],
        'CLP' => [
            'CLP',
            'Chilenesche Peso',
        ],
        'CNY' => [
            'CN¥',
            'Renminbi Yuan',
        ],
        'COP' => [
            'COP',
            'Kolumbianesche Peso',
        ],
        'CRC' => [
            'CRC',
            'Costa-Rica-Colón',
        ],
        'CSD' => [
            'CSD',
            'Serbeschen Dinar (2002–2006)',
        ],
        'CSK' => [
            'CSK',
            'Tschechoslowakesch Kroun',
        ],
        'CUC' => [
            'CUC',
            'Kubanesche Peso (konvertibel)',
        ],
        'CUP' => [
            'CUP',
            'Kubanesche Peso',
        ],
        'CVE' => [
            'CVE',
            'Kap-Verde-Escudo',
        ],
        'CYP' => [
            'CYP',
            'Zypern-Pond',
        ],
        'CZK' => [
            'CZK',
            'Tschechesch Kroun',
        ],
        'DDM' => [
            'DDM',
            'DDR-Mark',
        ],
        'DEM' => [
            'DEM',
            'Däitsch Mark',
        ],
        'DJF' => [
            'DJF',
            'Dschibuti-Frang',
        ],
        'DKK' => [
            'DKK',
            'Dänesch Kroun',
        ],
        'DOP' => [
            'DOP',
            'Dominikanesche Peso',
        ],
        'DZD' => [
            'DZD',
            'Algereschen Dinar',
        ],
        'ECS' => [
            'ECS',
            'Ecuadorianesche Sucre',
        ],
        'ECV' => [
            'ECV',
            'Verrechnungseenheete fir Ecuador',
        ],
        'EEK' => [
            'EEK',
            'Estnesch Kroun',
        ],
        'EGP' => [
            'EGP',
            'Egyptescht Pond',
        ],
        'ERN' => [
            'ERN',
            'Eritréieschen Nakfa',
        ],
        'ESA' => [
            'ESA',
            'Spuenesch Peseta (A–Konten)',
        ],
        'ESB' => [
            'ESB',
            'Spuenesch Peseta (konvertibel)',
        ],
        'ESP' => [
            'ESP',
            'Spuenesch Peseta',
        ],
        'ETB' => [
            'ETB',
            'Ethiopescht Birr',
        ],
        'EUR' => [
            '€',
            'Euro',
        ],
        'FIM' => [
            'FIM',
            'Finnesch Mark',
        ],
        'FJD' => [
            'FJD',
            'Fidschi-Dollar',
        ],
        'FKP' => [
            'FKP',
            'Falkland-Pond',
        ],
        'FRF' => [
            'FRF',
            'Franséische Frang',
        ],
        'GBP' => [
            '£',
            'Britescht Pond',
        ],
        'GEK' => [
            'GEK',
            'Georgesche Kupon Larit',
        ],
        'GEL' => [
            'GEL',
            'Georgesche Lari',
        ],
        'GHC' => [
            'GHC',
            'Ghanaeschen Cedi (1979–2007)',
        ],
        'GHS' => [
            'GHS',
            'Ghanaeschen Cedi',
        ],
        'GIP' => [
            'GIP',
            'Gibraltar-Pond',
        ],
        'GMD' => [
            'GMD',
            'Gambia-Dalasi',
        ],
        'GNF' => [
            'GNF',
            'Guinea-Frang',
        ],
        'GNS' => [
            'GNS',
            'Guinéiesche Syli',
        ],
        'GQE' => [
            'GQE',
            'Equatorialguinea-Ekwele',
        ],
        'GRD' => [
            'GRD',
            'Griichesch Drachme',
        ],
        'GTQ' => [
            'GTQ',
            'Guatemaltekesche Quetzal',
        ],
        'GWE' => [
            'GWE',
            'Portugisesch-Guinea Escudo',
        ],
        'GWP' => [
            'GWP',
            'Guinea-Bissau Peso',
        ],
        'GYD' => [
            'GYD',
            'Guyana-Dollar',
        ],
        'HKD' => [
            'HK$',
            'Hong-Kong-Dollar',
        ],
        'HNL' => [
            'HNL',
            'Honduras-Lempira',
        ],
        'HRD' => [
            'HRD',
            'Kroateschen Dinar',
        ],
        'HRK' => [
            'HRK',
            'Kroatesche Kuna',
        ],
        'HTG' => [
            'HTG',
            'Haitianesch Gourde',
        ],
        'HUF' => [
            'HUF',
            'Ungaresche Forint',
        ],
        'IDR' => [
            'IDR',
            'Indonesesch Rupiah',
        ],
        'IEP' => [
            'IEP',
            'Irescht Pond',
        ],
        'ILP' => [
            'ILP',
            'Israelescht Pond',
        ],
        'ILS' => [
            '₪',
            'Israeleschen Neie Schekel',
        ],
        'INR' => [
            '₹',
            'Indesch Rupie',
        ],
        'IQD' => [
            'IQD',
            'Irakeschen Dinar',
        ],
        'IRR' => [
            'IRR',
            'Iranesch Rial',
        ],
        'ISK' => [
            'ISK',
            'Islännesch Kroun',
        ],
        'ITL' => [
            'ITL',
            'Italienesch Lira',
        ],
        'JMD' => [
            'JMD',
            'Jamaika-Dollar',
        ],
        'JOD' => [
            'JOD',
            'Jordaneschen Dinar',
        ],
        'JPY' => [
            '¥',
            'Japanesche Yen',
        ],
        'KES' => [
            'KES',
            'Kenia-Schilling',
        ],
        'KGS' => [
            'KGS',
            'Kirgisesche Som',
        ],
        'KHR' => [
            'KHR',
            'Kambodschanesche Riel',
        ],
        'KMF' => [
            'KMF',
            'Komore-Frang',
        ],
        'KPW' => [
            'KPW',
            'Nordkoreanesche Won',
        ],
        'KRW' => [
            '₩',
            'Südkoreanesche Won',
        ],
        'KWD' => [
            'KWD',
            'Kuwait-Dinar',
        ],
        'KYD' => [
            'KYD',
            'Kaiman-Dollar',
        ],
        'KZT' => [
            'KZT',
            'Kasacheschen Tenge',
        ],
        'LAK' => [
            'LAK',
            'Laoteschen Kip',
        ],
        'LBP' => [
            'LBP',
            'Libanesescht Pond',
        ],
        'LKR' => [
            'LKR',
            'Sri-Lanka-Rupie',
        ],
        'LRD' => [
            'LRD',
            'Liberianeschen Dollar',
        ],
        'LSL' => [
            'LSL',
            'Loti',
        ],
        'LTL' => [
            'LTL',
            'Litauesche Litas',
        ],
        'LTT' => [
            'LTT',
            'Litaueschen Talonas',
        ],
        'LUC' => [
            'LUC',
            'Lëtzebuerger Frang (konvertibel)',
        ],
        'LUF' => [
            'LUF',
            'Lëtzebuerger Frang',
        ],
        'LUL' => [
            'LUL',
            'Lëtzebuerger Finanz-Frang',
        ],
        'LVL' => [
            'LVL',
            'Lettesche Lats',
        ],
        'LVR' => [
            'LVR',
            'Lettesche Rubel',
        ],
        'LYD' => [
            'LYD',
            'Libeschen Dinar',
        ],
        'MAD' => [
            'MAD',
            'Marokkaneschen Dirham',
        ],
        'MAF' => [
            'MAF',
            'Marokkanesche Frang',
        ],
        'MDL' => [
            'MDL',
            'Moldawesche Leu',
        ],
        'MGA' => [
            'MGA',
            'Madagaskar-Ariary',
        ],
        'MGF' => [
            'MGF',
            'Madagaskar-Frang',
        ],
        'MKD' => [
            'MKD',
            'Mazedoneschen Denar',
        ],
        'MLF' => [
            'MLF',
            'Malesche Frang',
        ],
        'MMK' => [
            'MMK',
            'Myanmaresche Kyat',
        ],
        'MNT' => [
            'MNT',
            'Mongoleschen Tögrög',
        ],
        'MOP' => [
            'MOP',
            'Macau-Pataca',
        ],
        'MRO' => [
            'MRO',
            'Mauretaneschen Ouguiya (1973–2017)',
        ],
        'MRU' => [
            'MRU',
            'Mauretaneschen Ouguiya',
        ],
        'MTL' => [
            'MTL',
            'Maltesesch Lira',
        ],
        'MTP' => [
            'MTP',
            'Maltesescht Pond',
        ],
        'MUR' => [
            'MUR',
            'Mauritius-Rupie',
        ],
        'MVR' => [
            'MVR',
            'Maldiven-Rupie',
        ],
        'MWK' => [
            'MWK',
            'Malawi-Kwacha',
        ],
        'MXN' => [
            'MX$',
            'Mexikanesche Peso',
        ],
        'MXP' => [
            'MXP',
            'Mexikanesche Sëlwer-Peso (1861–1992)',
        ],
        'MXV' => [
            'MXV',
            'Mexikaneschen Unidad de Inversion (UDI)',
        ],
        'MYR' => [
            'MYR',
            'Malayseschen Ringgit',
        ],
        'MZE' => [
            'MZE',
            'Mosambikaneschen Escudo',
        ],
        'MZM' => [
            'MZM',
            'Mosambikanesche Metical (1980–2006)',
        ],
        'MZN' => [
            'MZN',
            'Mosambikanesche Metical',
        ],
        'NAD' => [
            'NAD',
            'Namibia-Dollar',
        ],
        'NGN' => [
            'NGN',
            'Nigerianeschen Naira',
        ],
        'NIC' => [
            'NIC',
            'Nicaraguanesche Córdoba (1988–1991)',
        ],
        'NIO' => [
            'NIO',
            'Nicaraguanesche Córdoba',
        ],
        'NLG' => [
            'NLG',
            'Hollännesche Gulden',
        ],
        'NOK' => [
            'NOK',
            'Norwegesch Kroun',
        ],
        'NPR' => [
            'NPR',
            'Nepalesesch Rupie',
        ],
        'NZD' => [
            'NZ$',
            'Neiséiland-Dollar',
        ],
        'OMR' => [
            'OMR',
            'Omanesche Rial',
        ],
        'PAB' => [
            'PAB',
            'Panamaesche Balboa',
        ],
        'PEI' => [
            'PEI',
            'Peruaneschen Inti',
        ],
        'PEN' => [
            'PEN',
            'Peruaneschen Sol',
        ],
        'PES' => [
            'PES',
            'Peruaneschen Sol (1863–1965)',
        ],
        'PGK' => [
            'PGK',
            'Papua-Neiguinéiesche Kina',
        ],
        'PHP' => [
            'PHP',
            'Philippinnesche Peso',
        ],
        'PKR' => [
            'PKR',
            'Pakistanesch Rupie',
        ],
        'PLN' => [
            'PLN',
            'Polneschen Zloty',
        ],
        'PLZ' => [
            'PLZ',
            'Polneschen Zloty (1950–1995)',
        ],
        'PTE' => [
            'PTE',
            'Portugiseschen Escudo',
        ],
        'PYG' => [
            'PYG',
            'Paraguayeschen Guaraní',
        ],
        'QAR' => [
            'QAR',
            'Katar-Riyal',
        ],
        'RHD' => [
            'RHD',
            'Rhodeseschen Dollar',
        ],
        'ROL' => [
            'ROL',
            'Rumänesche Leu (1952–2006)',
        ],
        'RON' => [
            'RON',
            'Rumänesche Leu',
        ],
        'RSD' => [
            'RSD',
            'Serbeschen Dinar',
        ],
        'RUB' => [
            'RUB',
            'Russesche Rubel',
        ],
        'RUR' => [
            'RUR',
            'Russesche Rubel (1991–1998)',
        ],
        'RWF' => [
            'RWF',
            'Ruanda-Frang',
        ],
        'SAR' => [
            'SAR',
            'Saudi-Rial',
        ],
        'SBD' => [
            'SBD',
            'Salomonen-Dollar',
        ],
        'SCR' => [
            'SCR',
            'Seychellen-Rupie',
        ],
        'SDD' => [
            'SDD',
            'Sudaneseschen Dinar (1992–2007)',
        ],
        'SDG' => [
            'SDG',
            'Sudanesescht Pond',
        ],
        'SDP' => [
            'SDP',
            'Sudanesescht Pond (1957–1998)',
        ],
        'SEK' => [
            'SEK',
            'Schwedesch Kroun',
        ],
        'SGD' => [
            'SGD',
            'Singapur-Dollar',
        ],
        'SHP' => [
            'SHP',
            'St. Helena-Pond',
        ],
        'SIT' => [
            'SIT',
            'Sloweneschen Tolar',
        ],
        'SKK' => [
            'SKK',
            'Slowakesch Kroun',
        ],
        'SLE' => [
            'SLE',
            'Sierra-leonesche Leone',
        ],
        'SLL' => [
            'SLL',
            'Sierra-leonesche Leone (1964—2022)',
        ],
        'SOS' => [
            'SOS',
            'Somalia-Schilling',
        ],
        'SRD' => [
            'SRD',
            'Surinameschen Dollar',
        ],
        'SRG' => [
            'SRG',
            'Surinamesche Gulden',
        ],
        'SSP' => [
            'SSP',
            'Südsudanesescht Pond',
        ],
        'STD' => [
            'STD',
            'São-toméeschen Dobra (1977–2017)',
        ],
        'STN' => [
            'STN',
            'São-toméeschen Dobra',
        ],
        'SUR' => [
            'SUR',
            'Sowjetesche Rubel',
        ],
        'SVC' => [
            'SVC',
            'El-Salvador-Colón',
        ],
        'SYP' => [
            'SYP',
            'Syrescht Pond',
        ],
        'SZL' => [
            'SZL',
            'Swasilännesche Lilangeni',
        ],
        'THB' => [
            '฿',
            'Thailännesche Baht',
        ],
        'TJR' => [
            'TJR',
            'Tadschikistan-Rubel',
        ],
        'TJS' => [
            'TJS',
            'Tadschikistan-Somoni',
        ],
        'TMM' => [
            'TMM',
            'Turkmenistan-Manat (1993–2009)',
        ],
        'TMT' => [
            'TMT',
            'Turkmenistan-Manat',
        ],
        'TND' => [
            'TND',
            'Tuneseschen Dinar',
        ],
        'TOP' => [
            'TOP',
            'Tongaeschen Paʻanga',
        ],
        'TPE' => [
            'TPE',
            'Timor-Escudo',
        ],
        'TRL' => [
            'TRL',
            'Tierkesch Lira (1922–2005)',
        ],
        'TRY' => [
            'TRY',
            'Tierkesch Lira',
        ],
        'TTD' => [
            'TTD',
            'Trinidad-an-Tobago-Dollar',
        ],
        'TWD' => [
            'NT$',
            'Neien Taiwan-Dollar',
        ],
        'TZS' => [
            'TZS',
            'Tansania-Schilling',
        ],
        'UAH' => [
            'UAH',
            'Ukraineschen Hrywnja',
        ],
        'UAK' => [
            'UAK',
            'Ukrainesche Karbovanetz',
        ],
        'UGS' => [
            'UGS',
            'Uganda-Schilling (1966–1987)',
        ],
        'UGX' => [
            'UGX',
            'Uganda-Schilling',
        ],
        'USD' => [
            '$',
            'US-Dollar',
        ],
        'USN' => [
            'USN',
            'US Dollar (Nächsten Dag)',
        ],
        'USS' => [
            'USS',
            'US Dollar (Selwechten Dag)',
        ],
        'UYP' => [
            'UYP',
            'Uruguayesche Peso (1975–1993)',
        ],
        'UYU' => [
            'UYU',
            'Uruguayesche Peso',
        ],
        'UZS' => [
            'UZS',
            'Usbekistan-Sum',
        ],
        'VEB' => [
            'VEB',
            'Venezolanesche Bolívar (1871–2008)',
        ],
        'VEF' => [
            'VEF',
            'Venezolanesche Bolívar (2008–2018)',
        ],
        'VES' => [
            'VES',
            'Venezolanesche Bolívar',
        ],
        'VND' => [
            '₫',
            'Vietnameseschen Dong',
        ],
        'VUV' => [
            'VUV',
            'Vanuatu-Vatu',
        ],
        'WST' => [
            'WST',
            'Samoaneschen Tala',
        ],
        'XAF' => [
            'FCFA',
            'CFA-Frang (BEAC)',
        ],
        'XCD' => [
            'EC$',
            'Ostkaribeschen Dollar',
        ],
        'XEU' => [
            'XEU',
            'Europäesch Währungseenheet (XEU)',
        ],
        'XFO' => [
            'XFO',
            'Franséische Gold-Frang',
        ],
        'XFU' => [
            'XFU',
            'Franséischen UIC-Frang',
        ],
        'XOF' => [
            'F CFA',
            'CFA-Frang (BCEAO)',
        ],
        'XPF' => [
            'CFPF',
            'CFP-Frang',
        ],
        'XRE' => [
            'XRE',
            'RINET Funds',
        ],
        'YDD' => [
            'YDD',
            'Jemen-Dinar',
        ],
        'YER' => [
            'YER',
            'Jemen-Rial',
        ],
        'YUD' => [
            'YUD',
            'Jugoslaweschen Dinar (1966–1990)',
        ],
        'YUM' => [
            'YUM',
            'Jugoslaweschen Neien Dinar (1994–2002)',
        ],
        'YUN' => [
            'YUN',
            'Jugoslaweschen Dinar (konvertibel)',
        ],
        'ZAL' => [
            'ZAL',
            'Südafrikanesche Rand (Finanz)',
        ],
        'ZAR' => [
            'ZAR',
            'Südafrikanesche Rand',
        ],
        'ZMK' => [
            'ZMK',
            'Kwacha (1968–2012)',
        ],
        'ZMW' => [
            'ZMW',
            'Kwacha',
        ],
        'ZRN' => [
            'ZRN',
            'Zaire-Neien Zaïre (1993–1998)',
        ],
        'ZRZ' => [
            'ZRZ',
            'Zaire-Zaïre (1971–1993)',
        ],
        'ZWD' => [
            'ZWD',
            'Simbabwe-Dollar (1980–2008)',
        ],
        'ZWL' => [
            'ZWL',
            'Simbabwe-Dollar (2009)',
        ],
        'ZWR' => [
            'ZWR',
            'Simbabwe-Dollar (2008)',
        ],
    ],
];
