<?php

return [
    'Names' => [
        'gv' => 'Gaelg',
    ],
    'LocalizedNames' => [],
];
